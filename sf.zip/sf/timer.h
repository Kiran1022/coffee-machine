#ifndef _TIMER_H
#define _TIMER_H

#define CLOCKID CLOCK_REALTIME
#define SIG SIGUSR1
#define ONESHOT         0
#define PERIODIC        1
#define STOP_T          0
#define RUN_T           1
#define TMAX            10


struct timer
{
         char valid;
         char type;
         char status;
         int elapsed;
         int reload;
         int timerid;
         void (*ptr)();
};


int create_timer(int *timer_id, char type, char interval);
int start_timer(int timer_id, void (*ptr)());
:q!
:wq!




#endif

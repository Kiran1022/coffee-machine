#ifndef _COMMON_H
#define _COMMON_H

#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/msg.h>

#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>


#define SHM_PATH "common.h"
#define SHM_PROJ 75
#define TMAX 30

typedef enum task
{
        PROCMGR,
        ALARM,
        AUDIO,
        DELIVERY,
        DIAG,
        DISPLAY,
        EVENTLOG,
        MONITOR,
        MAX_TASKS,
	TIMER,
}TASKLISTS;

typedef enum state
{
        PRE_INITIALIZED,
        INITIALIZED,
        POST_COMPLETED,
        RUNNING,
        STOPPED,
        PRE_SHUTDOWN,
        SHUTDOWN
}TASKSTATES;

typedef enum 
{
        MSGQ_PROCMGR,
        MSGQ_ALARM,
        MSGQ_AUDIO,
        MSGQ_DELIVERY,
        MSGQ_DIAG,
        MSGQ_DISPLAY,
        MSGQ_EVENTLOG,
        MSGQ_MONITOR,
        MAX_QUEUES,
        MSGQ_TIMER,

}MSGQLIST;

typedef enum message
{
	// Timer Messages
	MSG_HEALTH_CHK_TIMER,
	MSG_DRUG_DELIVERY_TIMER,

        // System Messages
        MSG_TASK_CREATED,
        MSG_HEALTHCHK,
        MSG_HEALTHCHK_ACK,

	MSG_CREATE_TIMER,
	MSG_CREATE_START_TIMER,
	MSG_START_TIMER,
	MSG_STOP_TIMER,
	MSG_DELETE_TIMER,

	MSG_SHUTDOWN,
	MSG_SHUTDOWN_ACK,

        // Application Messages
        MSG_PING,
        MSG_PING_ACK,


	MSG_CHK1_7_TASK,
	MSG_CHK2_6_TASK,
	MSG_CHK3_5_TASK,

	MSG_START_DRUG_DELIVERY,
        MSG_MAX,
	MSG_UPDATE,
	MSG_ALARM_H,
	//Alarm messages
	MSG_PRESSURE_HIGH,
	MSG_PRESSURE_LOW,
	MSG_BATTERY_LOW,
	MSG_TEMP_HIGH,
	MSG_TEMP_LOW,
	MSG_DRUG_DELIVERY_END
	
}MESSAGE;

typedef enum timertype
{
	ONESHOT = 0,
	PERIODIC,
	MAX_TIMERTYPE
}TIMERTYPE;

typedef struct
{
        char state[MAX_TASKS];
	char hckack[MAX_TASKS];
	char shutdownack[MAX_TASKS];
}TASKINFO;

typedef struct {
        long mesg_type;
        char mesg_text[25];
}MSGQDATA;

struct ALARM
{
	char name[20];
	int priority;
	int running;
}alarms[7];

typedef struct 
{
        int taskid[MAX_TASKS];
        int msgqid[MAX_QUEUES];
	char processname[MAX_TASKS][25];
	char path[MAX_TASKS][25];
        int projid[MAX_TASKS];
	char timerstatus;
	char deliveryinprogress;
	int remainingvolume;
	int rate;
	int time;
	int pressure;
	int temperature;
	int battery; 
	char curr_alarm[50];
} SHMM_INFO, *PSHM_INFO;

typedef struct
{
	int count;
	int timerid;
	TASKLISTS taskid;
	MESSAGE msgid;
	TIMERTYPE timertype;
	int interval;
} TIMERSHM, *PTIMERSHM;

typedef struct 
{
         char valid;
         char type;
         char status;
         int elapsed;
         int reload;
         int timerid;
	 TASKLISTS taskid; 
	 MESSAGE msgid;	
}TIMERINFO;


int create_shm();
int remove_shm();
int create_msgq();
int remove_msgq();
int create_process();
void remove_process();
int send_msg(int taskid, MSGQDATA *mesg, int size);
int recv_msg(int taskid, MSGQDATA *mesg, int size);
int recv_msg_nowait(int taskid, MSGQDATA *mesg, int size);

void delay(unsigned long time);
char* itoa(int num, char* str, int base);

FILE *fp;


#endif

/* 

 * File: packbox.c
 * Auth: Eric Harlow
 *
 * Example of a packing box.
 */
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>
#include <gtk/gtk.h>
#include "common.h"

extern int SHMID;
extern SHMM_INFO shminfo;
extern PSHM_INFO pshminfo;


static int nSeconds = 0;                 
static gint timer = 0;
static int bTimerRunning = FALSE;
MSGQDATA message;

 GtkWidget *entry;
 GtkWidget *entry1;
 GtkWidget *entry2;
 GtkWidget *entry3;
 GtkWidget *entry4;
 GtkWidget *entry5;
    GtkWidget *listbox;
    GtkWidget *view;
    GtkWidget *view1;
	GtkWidget	*item;
	GList	*list;
GtkTextBuffer *buffer;
    GtkTextBuffer *buffer1;
//void UpdateSeconds (int);

/*
 * TimerCallback
 *
 * Every second, this will be called to update the time
 * in the clock window.
 */
gint TimerCallback (gpointer data)
{
	char buff[100];
	char str[100];
    /* --- Another second has gone by --- */
    nSeconds++;

	gtk_text_buffer_set_text (buffer1, pshminfo->curr_alarm, -1);
	//strcpy(pshminfo->curr_alarm ,alarms[6].name);
fp = fopen("eventlog.txt","r");
#if 0
	 itoa (pshminfo->time,buff,10);

	gtk_entry_set_text (GTK_ENTRY (entry2), buff);
	
	fgets(buff,100,fp);
	item=gtk_list_item_new_with_label(buff);
        list=g_list_prepend(list, item);
/*fgets(buff,100,fp);
	item=gtk_list_item_new_with_label(buff);
        list=g_list_prepend(list, item);
fgets(buff,100,fp);
	item=gtk_list_item_new_with_label(buff);
        list=g_list_prepend(list, item);
fgets(buff,100,fp);
	item=gtk_list_item_new_with_label(buff);
        list=g_list_prepend(list, item);
fgets(buff,100,fp);
	item=gtk_list_item_new_with_label(buff);
        list=g_list_prepend(list, item);
fgets(buff,100,fp);
	item=gtk_list_item_new_with_label(buff);
        list=g_list_prepend(list, item);
*/
	gtk_list_insert_items (listbox, list , 0);
	

#endif


		
	int i = 0;
	
	fgets(str,100,fp);
	/*strcat(buff,str);
	strcat(buff,"\n");
	fgets(str,100,fp);
	strcat(buff,str);
	strcat(buff,"\n");
	fgets(str,100,fp);
	strcat(buff,str);
	strcat(buff,"\n");
	fgets(str,100,fp);
	strcat(buff,str);
	strcat(buff,"\n");
	fgets(str,100,fp);
	strcat(buff,str);
	strcat(buff,"\n");
	fgets(str,100,fp);
	strcat(buff,str);
	strcat(buff,"\n");*/	
	gtk_text_buffer_set_text (buffer, str, -1);
	
fclose(fp);
    //UpdateSeconds (nSeconds);

    return 1; // NOTE: Needs to be non-zero otherwise timer seems to be stopped.
}


/*
 * StartTimer
 *
 * Starts up the time.  Happens when the user first
 * clicks on a button.
 */
void StartTimer ()
{

    /* --- If the timer isn't already running --- */
    if (!bTimerRunning) {

        /* --- Start at zero --- */
        nSeconds = 0;

        /* --- Call function 'TimerCallback' every 1000ms --- */
        timer = gtk_timeout_add (1000, TimerCallback, NULL);

        /* --- Timer is running. --- */
        bTimerRunning = TRUE;
    }
}

/*
 * StopTimer
 *
 * Stops the timer.  User probably hit a bomb.
 */
void StopTimer ()
{
    /* --- If the time is running. --- */
    if (bTimerRunning) {

        /* --- Stop the timer. --- */
        gtk_timeout_remove (timer);
 
        /* --- Fix the flag. --- */
        bTimerRunning = FALSE;
    }
}

void AddListItem (GtkWidget *listbox, char *sText);

/*
 * Destroy
 *
 * Close down the application
 */
gint CloseAppWindow (GtkWidget *widget, gpointer *data)
{
	MSGQDATA message;

	message.mesg_type = 1;
        message.mesg_text[0] = 3;
        message.mesg_text[1] = 11;
        message.mesg_text[2] = MSG_SHUTDOWN;
        printf ("*******Sending Expiry Message*************");
        send_msg(0, &message, sizeof(message));

    /* --- Shut down gtk event loop processing --- */
    gtk_main_quit ();

    /* --- FALSE => ok to close window --- */
    return (FALSE);
}

/*
 * button_event
 *
 * Some event happened and the name is passed in the
 * data field.
 */

void button_event (GtkWidget *widget, gpointer *data)
{
   //  g_print ("Button event: %s\n", data);
#if 1
	if ( strcmp(data, "clicked1") == 0 )
	{

                message.mesg_type = 1;
                message.mesg_text[0] = 5;
                message.mesg_text[1] = 12;
                message.mesg_text[2] = MSG_START_DRUG_DELIVERY;
                message.mesg_text[3] = atoi(gtk_entry_get_text (GTK_ENTRY(entry)));
                message.mesg_text[4] = atoi(gtk_entry_get_text (GTK_ENTRY(entry1)));
                send_msg(3, &message, sizeof(message));
		
		printf ("*************GUI SENDING MESSAGE TO DELIVERY****************\n");

        	// msgsnd to send message
        	//msgsnd(msgid, &message, sizeof(message), 0);

        	// display the message
        //	printf("Data send is : %s \n", message.mesg_text);

	}

	else if( strcmp(data, "clicked") == 0)
	{

		pshminfo->pressure = atoi(gtk_entry_get_text (GTK_ENTRY(entry3)));
		pshminfo->temperature = atoi(gtk_entry_get_text (GTK_ENTRY(entry4)));
		pshminfo->battery = atoi(gtk_entry_get_text (GTK_ENTRY(entry5)));
		message.mesg_type = 1;
                message.mesg_text[0] = 5;
                message.mesg_text[1] = 12;
                message.mesg_text[2] = MSG_UPDATE;
     
                send_msg(EVENTLOG, &message, sizeof(message));
		send_msg(MONITOR, &message, sizeof(message));
		printf ("*************GUI UPDATING INPUT VALUES****************\n");
	}
		
#endif
}


/*
 * Main - program begins here
 */
int main (int argc, char *argv[])
{
    GList *cbitems = NULL;
    GtkWidget *window;
    GtkWidget *button;
	GtkWidget *button1;

   
    GtkWidget *combo;
    GtkWidget *vbox;
	GtkWidget *vbox1;

    GtkWidget *box2;
    GtkWidget *check;
    GtkWidget *label;



    

    GtkWidget* scrolledwindow = gtk_scrolled_window_new(NULL, NULL);
	
    int which;

        printf ("Iam gui\n");
        int timer_id;
        MSGQDATA message;
        char buff[20];

        if (create_shm() == -1)
        {
                printf ("Shm creation error\n");
                exit(1);
        }

        if (create_msgq() == -1)
        {
                printf ("Msgq creation error\n");
                exit(1);
        }
//pshminfo->curr_alarm = &alarms[6];

    /* --- GTK initialization --- */
    gtk_init (&argc, &argv);
    
    /* --- Create the top level window --- */
    window = gtk_window_new (GTK_WINDOW_TOPLEVEL);

    /* --- You should always remember to connect the delete_event
     *     to the main window.
     */
    gtk_signal_connect (GTK_OBJECT (window), "delete_event",
			GTK_SIGNAL_FUNC (CloseAppWindow), NULL);

    /* --- Give the window a border --- */
    gtk_container_border_width (GTK_CONTAINER (window), 10);
    
    /* --- We create a vertical box (vbox) to pack 
     *     the horizontal boxes into. 
     */
    vbox = gtk_vbox_new (FALSE, 0);

  
#if 1
  /*
     * --- Create a Label
     */
    
    /* --- create a new label.  --- */
    label = gtk_label_new ("Pressure:");
	
    /* --- Align the label to the left side.   --- */
    gtk_misc_set_alignment (GTK_MISC (label), 0, 0);

    /* --- Pack the label into the vertical box (vbox box1).  --- */
    gtk_box_pack_start (GTK_BOX (vbox), label, FALSE, FALSE, 0);
	
    /* --- Show the label  --- */
    gtk_widget_show (label);


/* --- Create the field --- */
    entry3 = gtk_entry_new_with_max_length (20);

    /* --- Pack the entry into the vertical box (vbox box1).  --- */
    gtk_box_pack_start (GTK_BOX (vbox), entry3, FALSE, FALSE, 0);

    /* --- Put some text in the field. --- */
    gtk_entry_set_text (GTK_ENTRY (entry3), "0");

    /* --- Show the entry  --- */
    gtk_widget_show (entry3);

 /* --- create a new label.  --- */
    label = gtk_label_new ("Temperature");
	
    /* --- Align the label to the left side.   --- */
    gtk_misc_set_alignment (GTK_MISC (label), 0, 0);

    /* --- Pack the label into the vertical box (vbox box1).  --- */
    gtk_box_pack_start (GTK_BOX (vbox), label, FALSE, FALSE, 0);
	
    /* --- Show the label  --- */
    gtk_widget_show (label);


/* --- Create the field --- */
    entry4 = gtk_entry_new_with_max_length (20);

    /* --- Pack the entry into the vertical box (vbox box1).  --- */
    gtk_box_pack_start (GTK_BOX (vbox), entry4, FALSE, FALSE, 0);

    /* --- Put some text in the field. --- */
    gtk_entry_set_text (GTK_ENTRY (entry4), "0");

    /* --- Show the entry  --- */
    gtk_widget_show (entry4);


 /* --- create a new label.  --- */
    label = gtk_label_new ("Battery:");
	
    /* --- Align the label to the left side.   --- */
    gtk_misc_set_alignment (GTK_MISC (label), 0, 0);

    /* --- Pack the label into the vertical box (vbox box1).  --- */
    gtk_box_pack_start (GTK_BOX (vbox), label, FALSE, FALSE, 0);
	
    /* --- Show the label  --- */
    gtk_widget_show (label);


/* --- Create the field --- */
    entry5 = gtk_entry_new_with_max_length (20);

    /* --- Pack the entry into the vertical box (vbox box1).  --- */
    gtk_box_pack_start (GTK_BOX (vbox), entry5, FALSE, FALSE, 0);

    /* --- Put some text in the field. --- */
    gtk_entry_set_text (GTK_ENTRY (entry5), "0");

    /* --- Show the entry  --- */
    gtk_widget_show (entry5);



    /* 
     * --- Create a button
     */

    /* --- Create a new button. --- */
    button1 = gtk_button_new_with_label ("Update");

    /* --- Pack the button into the vertical box (vbox box1).  --- */
    gtk_box_pack_start (GTK_BOX (vbox), button1, FALSE, FALSE, 0);

    /* --- Show the button  --- */
    gtk_widget_show (button1);
	
    /*
     * --- Register event handlers
     */

  gtk_signal_connect (GTK_OBJECT (button1), "pressed",
                        GTK_SIGNAL_FUNC (button_event), "pressed");
    gtk_signal_connect (GTK_OBJECT (button1), "released",
                        GTK_SIGNAL_FUNC (button_event), "released");

    gtk_signal_connect (GTK_OBJECT (button1), "clicked",
                        GTK_SIGNAL_FUNC (button_event), "clicked");

    gtk_signal_connect (GTK_OBJECT (button1), "enter",
                        GTK_SIGNAL_FUNC (button_event), "enter");
    gtk_signal_connect (GTK_OBJECT (button1), "leave",
                        GTK_SIGNAL_FUNC (button_event), "leave");

#endif

	/*
     * --- Create a Label
     */
    
    /* --- create a new label.  --- */
    label = gtk_label_new ("Drug release volume:");
	
    /* --- Align the label to the left side.   --- */
    gtk_misc_set_alignment (GTK_MISC (label), 0, 0);

    /* --- Pack the label into the vertical box (vbox box1).  --- */
    gtk_box_pack_start (GTK_BOX (vbox), label, FALSE, FALSE, 0);
	
    /* --- Show the label  --- */
    gtk_widget_show (label);

    /* 
     * --- Create an entry field.
     */ 

    /* --- Create the field --- */
    entry = gtk_entry_new_with_max_length (20);

    /* --- Pack the entry into the vertical box (vbox box1).  --- */
    gtk_box_pack_start (GTK_BOX (vbox), entry, FALSE, FALSE, 0);

    /* --- Put some text in the field. --- */
    gtk_entry_set_text (GTK_ENTRY (entry), "0");

    /* --- Show the entry  --- */
    gtk_widget_show (entry);

	/*
     * --- Create a Label
     */
    
    /* --- create a new label.  --- */
    label = gtk_label_new ("Drug release rate");
	
    /* --- Align the label to the left side.   --- */
    gtk_misc_set_alignment (GTK_MISC (label), 0, 0);

    /* --- Pack the label into the vertical box (vbox box1).  --- */
    gtk_box_pack_start (GTK_BOX (vbox), label, FALSE, FALSE, 0);
	
    /* --- Show the label  --- */
    gtk_widget_show (label);


   /* --- Create the field --- */
    entry1 = gtk_entry_new_with_max_length (20);

    /* --- Pack the entry into the vertical box (vbox box1).  --- */
    gtk_box_pack_start (GTK_BOX (vbox), entry1, FALSE, FALSE, 0);

    /* --- Put some text in the field. --- */
    gtk_entry_set_text (GTK_ENTRY (entry1), "0");

    /* --- Show the entry  --- */
    gtk_widget_show (entry1);

	/*
     * --- Create a Label
     */
    
    /* --- create a new label.  --- */
    label = gtk_label_new ("Time remaining (s): ");
	
    /* --- Align the label to the left side.   --- */
    gtk_misc_set_alignment (GTK_MISC (label), 0, 0);

    /* --- Pack the label into the vertical box (vbox box1).  --- */
    gtk_box_pack_start (GTK_BOX (vbox), label, FALSE, FALSE, 0);
	
    /* --- Show the label  --- */
    gtk_widget_show (label);

   /* --- Create the field --- */
    entry2 = gtk_entry_new_with_max_length (20);

    /* --- Pack the entry into the vertical box (vbox box1).  --- */
    gtk_box_pack_start (GTK_BOX (vbox), entry2, FALSE, FALSE, 0);


    /* --- Put some text in the field. --- */
    gtk_entry_set_text (GTK_ENTRY (entry2), "0");

    /* --- Show the entry  --- */
    gtk_widget_show (entry2);

   


    /* --- Create a new button. --- */
    button = gtk_button_new_with_label ("Start drug delivery");

    gtk_box_pack_start (GTK_BOX (vbox), button, FALSE, FALSE, 0);
    /* --- Show the button  --- */
    gtk_widget_show (button);

    /*
     * --- Register event handlers
     */
    gtk_signal_connect (GTK_OBJECT (button), "pressed",
                        GTK_SIGNAL_FUNC (button_event), "pressed1");
    gtk_signal_connect (GTK_OBJECT (button), "released",
                        GTK_SIGNAL_FUNC (button_event), "released1");

    gtk_signal_connect (GTK_OBJECT (button), "clicked",
                        GTK_SIGNAL_FUNC (button_event), "clicked1");

    gtk_signal_connect (GTK_OBJECT (button), "enter",
                        GTK_SIGNAL_FUNC (button_event), "enter");
    gtk_signal_connect (GTK_OBJECT (button), "leave",
                        GTK_SIGNAL_FUNC (button_event), "leave");
		

	/* --- create a new label.  --- */
    label = gtk_label_new ("Active Alarm: ");
	
    /* --- Align the label to the left side.   --- */
    gtk_misc_set_alignment (GTK_MISC (label), 0, 0);

    /* --- Pack the label into the vertical box (vbox box1).  --- */
    gtk_box_pack_start (GTK_BOX (vbox), label, FALSE, FALSE, 0);
	
    /* --- Show the label  --- */
    gtk_widget_show (label);

#if 1
view1 = gtk_text_view_new ();

buffer1 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (view1));

gtk_text_buffer_set_text (buffer1, "Alarm", -1);

gtk_box_pack_start (GTK_BOX (vbox), view1, FALSE, FALSE, 0);
gtk_widget_show (view1);
#endif

/* --- create a new label.  --- */
    label = gtk_label_new ("Event Log:");
	
    /* --- Align the label to the left side.   --- */
    gtk_misc_set_alignment (GTK_MISC (label), 0, 0);

    /* --- Pack the label into the vertical box (vbox box1).  --- */
    gtk_box_pack_start (GTK_BOX (vbox), label, FALSE, FALSE, 0);
	
    /* --- Show the label  --- */
    gtk_widget_show (label);


#if 1
view = gtk_text_view_new ();

buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (view));

gtk_text_buffer_set_text (buffer, "Hello, this is some text", -1);

gtk_container_add(GTK_CONTAINER(scrolledwindow), view);

    gtk_box_pack_start (GTK_BOX (vbox), scrolledwindow, FALSE, FALSE, 0);
    /* --- Show the button  --- */
    gtk_widget_show (scrolledwindow);
    gtk_widget_show (view);	
#endif

#if 0
 





    /* 
     * --- Create a check button
     */

    /* --- Get the check button --- */
    check = gtk_check_button_new_with_label ("Check button");

    /* --- Pack the checkbox into the vertical box (vbox box1).  --- */
    gtk_box_pack_start (GTK_BOX (vbox), check, FALSE, FALSE, 0);

    /* --- Show the widget --- */
    gtk_widget_show (check);

    /* 
     * --- Create a listbox
     */

    /* --- Create the listbox --- */
    listbox = gtk_list_new ();

    /* --- Set listbox style. --- */
    gtk_list_set_selection_mode (GTK_LIST (listbox), GTK_SELECTION_BROWSE);

    /* --- Pack it in. --- */
    gtk_box_pack_start (GTK_BOX (vbox), listbox, FALSE, FALSE, 0);

    /* --- Make it visible --- */
    gtk_widget_show (listbox);

    AddListItem (listbox, "This is a listbox");
    AddListItem (listbox, "Quite useful ... ");
    AddListItem (listbox, "When it needs to be.");
    AddListItem (listbox, "This list can be ");
    AddListItem (listbox, "quite long, you know.");
	(listbox);

    /* 
     * --- Create a list of items
     */ 
    cbitems = g_list_append (cbitems, "Car");
    cbitems = g_list_append (cbitems, "House");
    cbitems = g_list_append (cbitems, "Job");
    cbitems = g_list_append (cbitems, "Computer");

    /*
     * --- Make a combo box.
     */ 
    combo = gtk_combo_new ();
    gtk_combo_set_popdown_strings (GTK_COMBO(combo), cbitems);
    gtk_entry_set_text (GTK_ENTRY (GTK_COMBO(combo)->entry), "Hello");

    /* --- Pack it in. --- */
    gtk_box_pack_start (GTK_BOX (vbox), combo, FALSE, FALSE, 0);

    /* --- Make it visible --- */
    gtk_widget_show (combo);
#endif


    /* 
     * --- Make the main window visible
     */ 
    gtk_container_add (GTK_CONTAINER (window), vbox);
    gtk_widget_show (vbox);
    gtk_widget_show (window);
	StartTimer();
	
    gtk_main ();
	StopTimer();
    exit (0);

}

/*
 * AddListItem
 *
 * Add an item to a listbox.
 */
void AddListItem (GtkWidget *listbox, char *sText)
{
	GtkWidget 	*item;

	/* --- Create a list item from the data element --- */
	item = gtk_list_item_new_with_label (sText);

	gtk_container_add (GTK_CONTAINER (listbox), item);

	gtk_widget_show (item);
}


#include "common.h"

extern int SHMID;
extern SHMM_INFO shminfo;
extern PSHM_INFO pshminfo;
extern int shutdwn;

TASKINFO tskinfo;

void checkshutdownack()
{
	int i;
	for (i=1;i<MAX_TASKS;i++)
	{
		if (tskinfo.shutdownack[i] == 0)
		{
			//printf ("%s not acknowledged shutdown\n",shminfo.path[i]);
			break;
		}
	}
        if (i == MAX_TASKS)
        {
        	printf ("Process Manager About to Exit\n");
                shutdwn = 1;
        }

}

void checkhealth()
{
	int i;
	for (i=0;i<MAX_TASKS;i++)
	{
		if (tskinfo.hckack[i] != 1)
		{
			//printf ("%s not acknowledged\n",shminfo.path[i]);
		}
	}
}

void main()
{
	int i;
	char buff[20];
	MSGQDATA message;

	if (create_shm() == -1)
	{
		printf ("Shm creation error\n");
		exit(1);
	}

	if (create_msgq() == -1)
	{
		printf ("Msgq creation error\n");
		exit(1);
	}

	if (create_process() == -1)
	{
		printf ("Fork error\n");
		exit(1);
	}

	for (i=1;i<MAX_TASKS;i++)
	{
#if 0
		message.mesg_type = 1;
		strcpy(&message.mesg_text[0], shminfo.path[i]);
#endif
#if 1
		message.mesg_type = 1;
		message.mesg_text[0] = 3;
                message.mesg_text[1] = 0;
                message.mesg_text[2] = MSG_PING;
                message.mesg_text[3] = '\0';
#endif
		send_msg(i, &message, sizeof(message));
		tskinfo.state[i] = PRE_INITIALIZED;
		tskinfo.shutdownack[message.mesg_text[1]] = 0;
		sleep(1);
	}


	i = 1;
	while(shutdwn == 0)
	{
		if (recv_msg(0, &message, sizeof(message)) != -1)
		{
			printf ("procmanager Received Message from Task %d \n", message.mesg_text[1]);

                        if (message.mesg_text[0] < 3)
                        {
                                printf ("Invalid Message \n");
                        }
                        else
                        {
                                //printf ("Valid Message %d\n", message.mesg_text[2]);
                                switch (message.mesg_text[2])
                                {
                                        case MSG_PING_ACK:
						tskinfo.state[message.mesg_text[1]] = INITIALIZED;						
						//printf ("State of Task %d is INITIALIED\n", \
								message.mesg_text[1]);
                                        break;
                                        case MSG_HEALTH_CHK_TIMER:
						message.mesg_type = 1;
						message.mesg_text[0] = 3;
				                message.mesg_text[1] = 0;
				                message.mesg_text[2] = MSG_HEALTHCHK;
				                message.mesg_text[3] = '\0';
						checkshutdownack();
						checkhealth();
						//printf("procmgr : Health Check Message Received \n");
						for (i=1;i<MAX_TASKS;i++)
						{
							tskinfo.hckack[i]= 0;
							send_msg(i, &message, sizeof(message));
						}
					break;
                                        case MSG_HEALTHCHK_ACK:
						tskinfo.hckack[message.mesg_text[1]] = 1;						
						//printf ("State of Task %d is HEALTHCHECK_ACK\n", \
								message.mesg_text[1]);
                                        break;
                                        case MSG_SHUTDOWN:
                                                message.mesg_type = 1;
                                                message.mesg_text[0] = 3;
                                                message.mesg_text[1] = 0;
                                                message.mesg_text[2] = MSG_SHUTDOWN;
                                                message.mesg_text[3] = '\0';
                                                //printf("procmgr : Shutdown message received from the GUI \n");
                                                for (i=1;i<MAX_TASKS;i++)
                                                {
                                                        tskinfo.hckack[i]= 0;
                                                        send_msg(i, &message, sizeof(message));
                                                }
                                        break;
                                        case MSG_SHUTDOWN_ACK:
                                                tskinfo.shutdownack[message.mesg_text[1]] = 1;
                                                //printf ("State of Task %d is SHUTDOWN_ACK\n", \
                                                                message.mesg_text[1]);
                                        break;
                                }
                        }

		}	
	}

	//remove_process();
	pshminfo->timerstatus = 0;


	for (i=1;i<MAX_TASKS;i++)
        {
	        waitpid(shminfo.taskid[i], NULL, 0);
                printf("PARENT: Child: %d returned value is: %d\n", i, WEXITSTATUS(shminfo.taskid[i]));
        }
        if (remove_shm() == -1)
        {
                printf ("Shm remove error\n");
                //exit(1);
        }

        if (remove_msgq() == -1)
        {
                printf ("Msgq remove error\n");
                //exit(1);
        }

}

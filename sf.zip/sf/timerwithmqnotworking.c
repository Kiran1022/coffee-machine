#include "common.h"
#include<time.h>
#include<signal.h>

#define CLOCKID CLOCK_REALTIME
#define SIG SIGUSR1
timer_t timerid;

extern int SHMID;
extern SHMM_INFO shminfo;
extern PSHM_INFO pshminfo;

TIMERINFO tm[TMAX];

void timer_isr(int sig, siginfo_t *si, void *uc)
{
	int i;
	MSGQDATA message;
	printf("Timer ISR\n");

        for (i =0;i < TMAX; i++)
        {
                if (tm[i].valid == 1 && tm[i].status == 1)
                {
                        --tm[i].elapsed;
                        if (tm[i].elapsed == 0)
                        {
                                printf ("Timer %d elapsed\n", tm[i].timerid);
                                if (tm[i].type == ONESHOT)
                                {
                                        tm[i].status = 0;
                                }
                                else
                                {
                                        tm[i].elapsed = tm[i].reload;
					message.mesg_text[0] = tm[i].taskid;
					message.mesg_text[1] = tm[i].msgid;
					send_msg(i, &message, sizeof(message));
                                        //tm[i].ptr();
                                }
                        }
                }
       }

}

int initialize_timer()
{
	struct sigevent sev;
    	struct itimerspec its;
    	long long freq_nanosecs;
    	sigset_t mask;
    	struct sigaction sa;

    	printf("Establishing handler for signal %d\n", SIG);
   	sa.sa_flags = SA_SIGINFO;
    	sa.sa_sigaction = timer_isr;
   	sigemptyset(&sa.sa_mask);
    	sigaction(SIG, &sa, NULL);

    	sev.sigev_notify = SIGEV_SIGNAL;
    	sev.sigev_signo = SIGUSR1;
    	sev.sigev_value.sival_ptr = &timerid;
    	timer_create(CLOCKID, &sev, &timerid);
    	/* Start the timer */

    	its.it_value.tv_sec = 1;
    	its.it_value.tv_nsec = 0;
    	its.it_interval.tv_sec = its.it_value.tv_sec;
    	its.it_interval.tv_nsec = its.it_value.tv_nsec;

    	timer_settime(timerid, 0, &its, NULL);
}


int create_timer(int *timer_id, TASKLISTS tskid, MESSAGE msgid, char type, char interval)
{
        int i;

        for (i=0; i < TMAX; i++)
        {
                if (tm[i].valid == 0)
                {
                        *timer_id     = i + 1;
                        tm[i].valid   = 1;
                        tm[i].type    = type;
                        tm[i].elapsed = interval;
                        tm[i].reload  = interval;
                        tm[i].status  = 0;
			tm[i].taskid = tskid;
			tm[i].msgid = msgid;
                        tm[i].timerid = i + 1;
                        break;
                }
        }

        if (i == TMAX)
        {
                *timer_id = -1;
                return -1;
        }
        else
        {
                printf("Timer has been created, timer id = %d.\n",i+1);
                return i+1;
        }
}

int start_timer(int timer_id)
{
        int i = timer_id - 1;
        if (timer_id <0 || timer_id > TMAX)
        {
                printf ("Invalid Timer ID\n");
                return -1;
        }

        if (tm[i].valid == 1)
        {
                tm[i].status  = 1;
                //tm[i].ptr = ptr;
                printf ("Timer %d started\n", timer_id);
                return 0;
        }
        else
        {
                printf ("Timer ID not created\n");
                return -1;
        }
}

int stop_timer(int timer_id)
{
        int i = timer_id - 1;
        if (timer_id <0 || timer_id > TMAX)
        {
                printf ("Invalid Timer ID\n");
                return -1;
        }

        if (tm[i].valid == 1)
        {
		tm[i].valid = 0;
                tm[i].status  = 0;
                //tm[i].ptr = ptr;
                printf ("Timer %d started\n", timer_id);
                return 0;
        }
        else
        {
                printf ("Timer ID not created\n");
                return -1;
        }
}


void main()
{
	printf ("Iam timer\n");
        MSGQDATA message;
        char buff[20];
	int timer_id;

        if (create_shm() == -1)
        {
                printf ("Shm creation error\n");
                exit(1);
        }

        if (create_msgq() == -1)
        {
                printf ("Msgq creation error\n");
                exit(1);
        }

	initialize_timer();

        while(1)
        {
                if (recv_msg(8, &message, sizeof(message)) != -1)
                {
                        printf("timer received message \n");
			if (message.mesg_text[0] > 2)
			{
				switch (message.mesg_text[2])
				{
					case MSG_CREATE_START_TIMER:
						printf("Request to create and start timer\n");
						create_timer(&timer_id, message.mesg_text[1],message.mesg_text[5],\
								message.mesg_text[3], message.mesg_text[4]);
						start_timer(timer_id);
					break;
				}
			}
                }
        }

}

#include "common.h"
extern int shutdwn;

int  main(int argc, char *argv[])
{
	printf ("Iam diag %d\n", shutdwn);
        MSGQDATA message;
        char buff[20];
        if (create_shm() == -1)
        {
                printf ("Shm creation error\n");
                exit(1);
        }

        if (create_msgq() == -1)
        {
                printf ("Msgq creation error\n");
                exit(1);
        }

        while(shutdwn == 0)
        {
                if (recv_msg(4, &message, sizeof(message)) != -1)
                {
                        printf("diag received message \n");
                        if (message.mesg_text[0] < 3)
                        {
                                printf ("Invalid Message \n");
                        }
                        else
                        {
                                switch (message.mesg_text[2])
                                {
                                        case MSG_PING:
						message.mesg_type = 1;
                                                message.mesg_text[0] = 3;
                                                message.mesg_text[1] = 4;
                                                message.mesg_text[2] = MSG_PING_ACK;
                                                send_msg(0, &message, sizeof(message));
                                        break;
                                        case MSG_HEALTHCHK:
                                                message.mesg_type = 1;
                                                message.mesg_text[0] = 3;
                                                message.mesg_text[1] = 4;
                                                message.mesg_text[2] = MSG_HEALTHCHK_ACK;
                                                send_msg(0, &message, sizeof(message));
                                        break;
                                        case MSG_SHUTDOWN:
                                                message.mesg_type = 1;
                                                message.mesg_text[0] = 3;
                                                message.mesg_text[1] = 4;
                                                message.mesg_text[2] = MSG_SHUTDOWN_ACK;
                                                send_msg(0, &message, sizeof(message));
						shutdwn = 1;
                                        break;

                                }
                        }
                }
        }
        printf ("Diag task exit \n");
        exit (0);

}

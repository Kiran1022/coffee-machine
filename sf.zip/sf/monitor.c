#include "common.h"
extern int shutdwn;

extern int SHMID;
extern SHMM_INFO shminfo;
extern PSHM_INFO pshminfo;


int main(int argc, char *argv[])
{
	printf ("Iam monitor %d\n", shutdwn);
        MSGQDATA message;
        char buff[20];
        if (create_shm() == -1)
        {
                printf ("Shm creation error\n");
                exit(1);
        }

        if (create_msgq() == -1)
        {
                printf ("Msgq creation error\n");
                exit(1);
        }

        while(shutdwn == 0)
        {
                if (recv_msg(7, &message, sizeof(message)) != -1)
                {
                        printf("monitor received message \n");
			if (message.mesg_text[0] < 3)
			{
				printf ("Invalid Message \n");
			}
			else
			{
				switch (message.mesg_text[2])
				{
					case MSG_PING:
						message.mesg_type = 1;
                        			message.mesg_text[0] = 3;
                        			message.mesg_text[1] = 7;
                        			message.mesg_text[2] = MSG_PING_ACK;
                        			send_msg(0, &message, sizeof(message));
					break;
                                        case MSG_HEALTHCHK:
                                                message.mesg_type = 1;
                                                message.mesg_text[0] = 3;
                                                message.mesg_text[1] = 7;
                                                message.mesg_text[2] = MSG_HEALTHCHK_ACK;
                                                send_msg(0, &message, sizeof(message));
                                        break;
                                       	case MSG_CHK1_7_TASK:
						printf ("Task 7 received test message from Task 1\n");	
						sleep(1);
                                       	break;
                                        case MSG_SHUTDOWN:
                                                message.mesg_type = 1;
                                                message.mesg_text[0] = 3;
                                                message.mesg_text[1] = 7;
                                                message.mesg_text[2] = MSG_SHUTDOWN_ACK;
                                                send_msg(0, &message, sizeof(message));
						shutdwn = 1;
                                        break;
					case MSG_UPDATE:
						message.mesg_type = 1;
                                                message.mesg_text[0] = 3;
                                                message.mesg_text[1] = 7;
                                                
						if(pshminfo->pressure > 100)
						{
							message.mesg_text[2] = MSG_PRESSURE_HIGH;
                                                	send_msg(ALARM, &message, sizeof(message));
						}
						
						else if(pshminfo->pressure < 50)
						{
							message.mesg_text[2] = MSG_PRESSURE_LOW;
                                                	send_msg(ALARM, &message, sizeof(message));
						}
						else 
						{
							message.mesg_text[2] = MSG_PRESSURE_LOW;
                                                	send_msg(ALARM, &message, sizeof(message));
						}
						if(pshminfo->temperature > 100)
						{
							message.mesg_text[2] = MSG_TEMP_HIGH;
                                                	send_msg(ALARM, &message, sizeof(message));
						}
						/*if(pshminfo->temperature < 20)
						{
							message.mesg_text[2] = MSG_TEMP_LOW;
                                                	send_msg(ALARM, &message, sizeof(message));
						}
						if(pshminfo->battery < 20)
						{
							message.mesg_text[2] = MSG_BATTERY_LOW;
                                                	send_msg(ALARM, &message, sizeof(message));
						}*/
							

				}
			}
                }

		
        }
        printf ("Monitor task exit \n");
        exit (0);

}

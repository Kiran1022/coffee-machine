#include "common.h"
extern int shutdwn;

extern int SHMID;
extern SHMM_INFO shminfo;
extern PSHM_INFO pshminfo;


char delivery_status = 0;


int main(int argc, char *argv[])
{
	printf ("Iam delivery %d\n", shutdwn);
        MSGQDATA message;
        char buff[20];
        if (create_shm() == -1)
        {
                printf ("Shm creation error\n");
                exit(1);
        }

        if (create_msgq() == -1)
        {
                printf ("Msgq creation error\n");
                exit(1);
        }

        while(shutdwn == 0)
        {
                if (recv_msg(3, &message, sizeof(message)) != -1)
                {
                        printf("delivery received message \n");
                        if (message.mesg_text[0] < 3)
                        {
                                printf ("Invalid Message \n");
                        }
                        else
                        {
                                switch (message.mesg_text[2])
                                {
                                        case MSG_PING:
						message.mesg_type = 1;
                                                message.mesg_text[0] = 3;
                                                message.mesg_text[1] = 3;
                                                message.mesg_text[2] = MSG_PING_ACK;
                                                send_msg(0, &message, sizeof(message));
                                        break;
                                        case MSG_HEALTHCHK:
                                                message.mesg_type = 1;
                                                message.mesg_text[0] = 3;
                                                message.mesg_text[1] = 3;
                                                message.mesg_text[2] = MSG_HEALTHCHK_ACK;
                                                send_msg(0, &message, sizeof(message));
                                        break;
                                       case MSG_CHK3_5_TASK:
                                                message.mesg_type = 1;
                                                message.mesg_text[0] = 3;
                                                message.mesg_text[1] = 3;
                                                message.mesg_text[2] = MSG_CHK3_5_TASK;
                                                send_msg(6, &message, sizeof(message));
                                        break;
                                        case MSG_SHUTDOWN:
                                                message.mesg_type = 1;
                                                message.mesg_text[0] = 3;
                                                message.mesg_text[1] = 3;
                                                message.mesg_text[2] = MSG_SHUTDOWN_ACK;
                                                send_msg(0, &message, sizeof(message));
						shutdwn = 1;
                                        break;
					case MSG_START_DRUG_DELIVERY:
						printf ("*************MSG_START_DRUG_DELIVERY****************\n");

						if (delivery_status == 0)
						{
							printf ("Start drug delivery\n");
							delivery_status = 1;
							pshminfo->deliveryinprogress = 1;
							// calculate volume
							// Calculate pump speed
							
							// time = volume/rate
							pshminfo->remainingvolume = message.mesg_text[3];
							pshminfo->rate =  message.mesg_text[4];
							pshminfo->time = pshminfo->remainingvolume/pshminfo->rate;
						}	
						else
						{
							printf ("Stop drug delivery\n");
							delivery_status = 0;
							pshminfo->deliveryinprogress = 0;
						}
					break;
					case MSG_DRUG_DELIVERY_TIMER:
						printf ("*************MSG_DRUG_DELIVERY_TIMER****************\n");
						if (delivery_status == 1)
						{
							printf ("Drug Timer Expiry\n");
							pshminfo->time--;
							pshminfo->remainingvolume=(pshminfo->time)*(pshminfo->rate);
							if (pshminfo->time <=0)
							{
								printf ("Stop drug delivery\n");
								delivery_status = 0;
								pshminfo->deliveryinprogress = 0;
								message.mesg_type = 1;
                                        		        message.mesg_text[0] = 3;
                                           		    	message.mesg_text[1] = 3;
                                            		    	message.mesg_text[2] = MSG_DRUG_DELIVERY_END;
                                             		   	send_msg(ALARM, &message, sizeof(message));
								
							}

						}
                                        break;

                                }
                        }
                }
        }
        printf ("Delivery task exit \n");
        exit (0);


}

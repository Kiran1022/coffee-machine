#include<stdio.h>
#include<time.h>
#include<signal.h>

#define CLOCKID CLOCK_REALTIME
#define SIG SIGUSR1
timer_t timerid;

#define ONESHOT 	0
#define PERIODIC 	1
#define STOP_T 		0
#define RUN_T 		1
#define TMAX 		10

static int X=0;
char TIF;
char TCOUNT=0;
timer_t gTimerid;

void func1();
void func2();
void func3();
void func4();
void func5();
void func6();
void func7();
void func8();
void func9();
void func10();

void timer_isr(int sig, siginfo_t *si, void *uc)
{
	TIF = 1;	
}

struct timer
{
	 char valid;
	 char type;
 	 char status;
	 int elapsed;
	 int reload;
	 int timerid;	
	 void (*ptr)();
};

struct timer tm[TMAX];

int create_timer(int *timer_id, char type, char interval)
{
	int i;

	for (i=0; i < TMAX; i++)
	{
		if (tm[i].valid == 0)
		{
			*timer_id     = i + 1;
			tm[i].valid   = 1;
			tm[i].type    = type;
			tm[i].elapsed = interval;
			tm[i].reload  = interval;
			tm[i].status  = 0;
			tm[i].timerid = i + 1;
			break;
		}
	}

	if (i == TMAX)
	{
		*timer_id = -1;
		return -1;
	}
	else
	{
        	printf("Timer has been created, timer id = %d.\n",i+1);  
		return i+1;
	}
}

int start_timer(int timer_id, void (*ptr)())
{
	int i = timer_id - 1;
	if (timer_id <0 || timer_id > TMAX)
	{
		printf ("Invalid Timer ID\n");
		return -1;
	}

	if (tm[i].valid == 1)
	{
		tm[i].status  = 1;
		tm[i].ptr = ptr;
		printf ("Timer %d started\n", timer_id);
		return 0;
	}
	else
	{
		printf ("Timer ID not created\n");
		return -1;
	}
}

void func1()
{
	printf ("Starting func1 \n");
}

void func2()
{
	printf ("Starting func2 \n");
}

void func3()
{
	printf ("Starting func3 \n");
}

void func4()
{
	printf ("Starting func4 \n");
}

void func5()
{
	printf ("Starting func5 \n");
}

void func6()
{
	printf ("Starting func6 \n");
}

void func7()
{
	printf ("Starting func7 \n");
}

void func8()
{
	printf ("Starting func8 \n");
}

void func9()
{
	printf ("Starting func9 \n");
}

void func10()
{
	printf ("Starting func10 \n");
}

int main(int ac, char **av)
{
	int tm_id[TMAX] = {0};
	static int count = 0;


    struct sigevent sev;
    struct itimerspec its;
    long long freq_nanosecs;
    sigset_t mask;
    struct sigaction sa;

    printf("Establishing handler for signal %d\n", SIG);
    sa.sa_flags = SA_SIGINFO;
    sa.sa_sigaction = timer_isr;
    sigemptyset(&sa.sa_mask);
    sigaction(SIG, &sa, NULL);

    sev.sigev_notify = SIGEV_SIGNAL;
    sev.sigev_signo = SIGUSR1;
    sev.sigev_value.sival_ptr = &timerid;
    timer_create(CLOCKID, &sev, &timerid);
    /* Start the timer */

    its.it_value.tv_sec = 0;
    its.it_value.tv_nsec = 100000000;
    its.it_interval.tv_sec = its.it_value.tv_sec;
    its.it_interval.tv_nsec = its.it_value.tv_nsec;

    timer_settime(timerid, 0, &its, NULL);


	if ( create_timer (&tm_id[0], ONESHOT, 30) == -1)
	{
		printf ("Timer creation failed");
	}
	if ( create_timer (&tm_id[1], PERIODIC, 5) == -1)
	{
		printf ("Timer creation failed");
	}
	if ( create_timer (&tm_id[2], ONESHOT, 40) == -1)
	{
		printf ("Timer creation failed");
	}
	if ( create_timer (&tm_id[3], PERIODIC, 10) == -1)
	{
		printf ("Timer creation failed");
	}
	if ( create_timer (&tm_id[4], ONESHOT, 50) == -1)
	{
		printf ("Timer creation failed");
	}
	if ( create_timer (&tm_id[5], PERIODIC, 15) == -1)
	{
		printf ("Timer creation failed");
	}
	if ( create_timer (&tm_id[6], ONESHOT, 60) == -1)
	{
		printf ("Timer creation failed");
	}
	if ( create_timer (&tm_id[7], PERIODIC, 20) == -1)
	{
		printf ("Timer creation failed");
	}
	if ( create_timer (&tm_id[8], ONESHOT, 70) == -1)
	{
		printf ("Timer creation failed");
	}
	if ( create_timer (&tm_id[9], PERIODIC, 25) == -1)
	{
		printf ("Timer creation failed");
	}

	if ( start_timer (tm_id[0], func1) == -1)
	{
		printf ("Timer start failed\n");
	}
	if ( start_timer (tm_id[1], func2) == -1)
	{
		printf ("Timer start failed\n");
	}
	if ( start_timer (tm_id[2], func3) == -1)
	{
		printf ("Timer start failed\n");
	}
	if ( start_timer (tm_id[3], func4) == -1)
	{
		printf ("Timer start failed\n");
	}
	if ( start_timer (tm_id[4], func5) == -1)
	{
		printf ("Timer start failed\n");
	}
	if ( start_timer (tm_id[5], func6) == -1)
	{
		printf ("Timer start failed\n");
	}
	if ( start_timer (tm_id[6], func7) == -1)
	{
		printf ("Timer start failed\n");
	}
	if ( start_timer (tm_id[7], func8) == -1)
	{
		printf ("Timer start failed\n");
	}
	if ( start_timer (tm_id[8], func9) == -1)
	{
		printf ("Timer start failed\n");
	}
	if ( start_timer (tm_id[9], func10) == -1)
	{
		printf ("Timer start failed\n");
	}

	while (1)
	{
		if (TIF == 1)
		{
			TIF = 0;
			count++ ;
			if (count == 10)
			{
				printf ("One second elapsed\n");
				count = 0;
				for (int i =0;i < TMAX; i++)
				{
					if (tm[i].valid == 1 && tm[i].status == 1)
					{

						--tm[i].elapsed;
						if (tm[i].elapsed == 0)
						{	
							printf ("Timer %d elapsed\n", tm[i].timerid);
							if (tm[i].type == ONESHOT)
							{
								tm[i].status = 0;
							}
							else
							{
								tm[i].elapsed = tm[i].reload;
								tm[i].ptr();
							}
						}
					}
				}
				
			}
		}
	}
}

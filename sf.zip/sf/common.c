#include "common.h"

int SHMID;
SHMM_INFO shminfo =     {
                                {1,2,3,4,5,6,7,8},
                                {8,7,6,5,4,3,2,1},
                                {"./procmgr" ,
                                 "./alarm",
                                 "./audio",
                                 "./delivery",
                                 "./diag",
                                 "./display",
                                 "./eventlog",
                                 "./monitor"},
                                {"procmgr.c" ,
                                 "alarm.c",
                                 "audio.c",
                                 "delivery.c",
                                 "diag.c",
                                 "display.c",
                                 "eventlog.c",
                                 "monitor.c"},
                                {61,62,63,64,65,66,67,68},
                           };

PSHM_INFO pshminfo;
int shutdwn = 0;

char *args[] = {"Started", NULL};

int create_shm()
{
	key_t key;
        key = ftok(SHM_PATH, SHM_PROJ);
        if (key == -1)
        {
                printf ("Shm key creation error errno %d errstr %s \n",errno, strerror(errno));
                return -1;
        }
        // shmget returns an identifier in shmid
        int SHMID = shmget(key,sizeof(SHM_INFO),0666|IPC_CREAT);

        if (SHMID == -1)
        {
                //printf ("Shm creation error errno %d, errstr %s\n", errno, strerror(errno));
                return SHMID;
        }
        else
        {
                //printf ("shmid %d\n", SHMID);

                pshminfo = (PSHM_INFO ) shmat(SHMID,NULL,0);
                if ((int) pshminfo == -1)
                {
                        printf ("Shm attachment error errno %d, errstr %s\n", errno, strerror(errno));
                        return (int) pshminfo;
                }
                else
                {
                        //printf ("pshminfo %x &shminfo %x shminfo %x\n", pshminfo, &shminfo, shminfo);
                        return 0;
                }
        }
}


int remove_shm()
{
        //detach from shared memory
        if (shmdt(pshminfo) == -1)
        {
                //printf ("Shm detachment error errno %d, errstr %s\n", errno, strerror(errno));
                return -1;
        }
        else
        {
                // destroy the shared memory
                if (shmctl(SHMID, IPC_RMID, NULL) == -1)
                {
                        //printf ("Shm destory error errno %d errstr %s \n",errno, strerror(errno));
                        return -1;
                }

        }
	return -1;
}

int create_msgq()
{
	int i;
	key_t key[MAX_TASKS];

        for (i=0;i<MAX_TASKS;i++)
        {
               	//printf ("path[%d] %s projid[%d] %d \n",i, shminfo.path[i], i,shminfo.projid[i]);
                // ftok to generate unique key
                key[i] = ftok(shminfo.path[i], shminfo.projid[i]);
	        if (key[i] == -1)
        	{
                	//printf ("Msgq key creation error errno %d errstr %s \n",errno, strerror(errno));
                	return -1;
        	}
		else
		{
                	//printf ("key[%d] = %d\n", i, key[i]);

                	// msgget creates a message queue
                	shminfo.msgqid[i] = msgget(key[i], 0666 | IPC_CREAT);
			if (shminfo.msgqid[i] == -1)
			{
                		//printf ("Msgq creation error errno %d errstr %s \n",errno, strerror(errno));
				return -1;
			}
			else
			{
				//printf ("msgq %d id %d\n", shminfo.msgqid[i]);
			}
		}
        }
	return 0;
}


int send_msg(int taskid, MSGQDATA *mesg, int size)
{

	int i, retval;	
	MSGQDATA message;
	memset(&message, 0, sizeof(message));
	message.mesg_type = 1;
	memcpy (&message, mesg, sizeof(message));
	retval = msgsnd(shminfo.msgqid[taskid], &message, sizeof(message), 0);
	if (retval != 0)
	{
                printf("Task %d message send error errno %d errstr %s\n", taskid, errno, strerror(errno));
	}
	else
	{
		//for (i=0;i<message.mesg_text[0];i++)
		//{
		//	printf ("%d", message.mesg_text[i]);
		//}
		printf ("\n");
		printf ("Message to task %d is sent \n", taskid);
		return 0;
	}
}

int recv_msg(int taskid, MSGQDATA  *mesg, int size)
{
	int i, msgsize;	
	MSGQDATA message;

	msgsize = msgrcv(shminfo.msgqid[taskid], &message, sizeof(message), 1, 0);

        if (msgsize == -1)
        {
	        // display the message
                printf("Task %d message receive error errno %d errstr %s\n", taskid, errno, strerror(errno));
		return -1;
        }
        else
        {
		memcpy (mesg, &message, sizeof(message));
        	printf("..Received message of size %d :  ", msgsize);
		for (i = 0;i<msgsize;i++)
		{
        		printf("%d", message.mesg_text[i]);
		}
		printf("\n");
		return msgsize;
        }
}

int recv_msg_nowait(int taskid, MSGQDATA  *mesg, int size)
{
	int i, msgsize;	
	MSGQDATA message;

	//msgsize = msgrcv(shminfo.msgqid[taskid], &message, sizeof(message), 1, MSG_NOERROR | IPC_NOWAIT);
	msgsize = msgrcv(shminfo.msgqid[taskid], &message, sizeof(message), 1, IPC_NOWAIT);

        if (msgsize == -1 || errno == ENOMSG)
        {
	        // display the message
                //printf("Task %d message receive error errno %d errstr %s\n", taskid, errno, strerror(errno));
		return -1;
        }
        else
        {
		memcpy (mesg, &message, sizeof(message));
        	printf("Received message of size %d :  ", msgsize);
		for (i = 0;i<msgsize;i++)
		{
        		printf("%c", message.mesg_text[i]);
		}
		printf("\n");
		return msgsize;
        }
}


int remove_msgq()
{
	int i;
	for (i = 0; i < MAX_TASKS; i++)
	{
		// to destroy the message queue
        	if (msgctl(shminfo.msgqid[i], IPC_RMID, NULL) == -1)
		{
			printf ("Msgq deletion error errno %d errstr %s \n",errno, strerror(errno));
			return -1;
		}
	}
	return 0;

}

int create_process()
{
	int i, pid;

	for (i=1;i<MAX_TASKS;i++)
        {
                pid = fork();
                if (pid == 0)
                {
                        shminfo.taskid[i] = getpid();
                        printf("Starting the task[%d]- %s, process id %d\n", i, shminfo.processname[i], shminfo.taskid[i]);
                        execv(shminfo.processname[i], args);
                }
		else
		{
			sleep(1);
		}
	}
        pid = fork();
        if (pid == 0)
        {
        	//shminfo.taskid[i] = getpid();
		pshminfo->timerstatus = 1;
                printf("Starting the Timer task\n");
                execv("./timer", args);
	}
	else
	{
		sleep(1);
	}
        pid = fork();
        if (pid == 0)
        {
        	//shminfo.taskid[i] = getpid();
                printf("Starting the GUI task\n");
                execv("./gui", args);
	}
	else
	{
		sleep(1);
	}
	return 0;
}

void remove_process()
{
	int i;
	char buff[50];

        for (i=1;i<MAX_TASKS;i++)
        {
		sprintf (buff, "kill -9 %d", shminfo.taskid[i]);
		system (buff);
        }

}
	
void delay(unsigned long time)
{
	int i,j;
	for (j=0;j<100;j++)
		for (i=0;i<time;i++);
}

void reverse(char str[], int length) 
{ 
	char t;
    int start = 0; 
    int end = length -1; 
    while (start < end) 
    { 
        t = str[start];
	str[start] = str[end];
	str[end] = t; 
        start++; 
        end--; 
    } 
} 

// Implementation of itoa() 
char* itoa(int num, char* str, int base) 
{ 
    int i = 0; 
    bool isNegative = false; 
  
    /* Handle 0 explicitely, otherwise empty string is printed for 0 */
    if (num == 0) 
    { 
        str[i++] = '0'; 
        str[i] = '\0'; 
        return str; 
    } 
  
    // In standard itoa(), negative numbers are handled only with  
    // base 10. Otherwise numbers are considered unsigned. 
    if (num < 0 && base == 10) 
    { 
        isNegative = true; 
        num = -num; 
    } 
  
    // Process individual digits 
    while (num != 0) 
    { 
        int rem = num % base; 
        str[i++] = (rem > 9)? (rem-10) + 'a' : rem + '0'; 
        num = num/base; 
    } 
  
    // If number is negative, append '-' 
    if (isNegative) 
        str[i++] = '-'; 
  
    str[i] = '\0'; // Append string terminator 
  
    // Reverse the string 
    reverse(str, i); 
  
    return str; 
} 

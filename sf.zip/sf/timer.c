#include "common.h"
#include<time.h>
#include<signal.h>

#define CLOCKID CLOCK_REALTIME
#define SIG SIGUSR1
timer_t timerid;

extern int SHMID;
extern SHMM_INFO shminfo;
extern PSHM_INFO pshminfo;
extern int shutdwn;

TIMERINFO tm[TMAX];
int create_timer(int *timer_id, TASKLISTS tskid, MESSAGE msgid, char type, char interval);
void delete_timer();

void check_message()
{
	int timer_id;
	MSGQDATA message;

	printf("Inside check_message\n");
                if (recv_msg_nowait(8, &message, sizeof(message)) != -1)
                {
                        printf("timer received message \n");
                        if (message.mesg_text[0] > 2)
                        {
                                switch (message.mesg_text[2])
                                {
                                        case MSG_CREATE_START_TIMER:
                                                printf("Request to create and start timer\n");
                                                create_timer(&timer_id, message.mesg_text[1],message.mesg_text[5],\
                                                                message.mesg_text[3], message.mesg_text[4]);
                                                start_timer(timer_id);
                                        break;
                                }
                        }
                }
}

void timer_isr(int sig, siginfo_t *si, void *uc)
{
	int i;
	MSGQDATA message;
	//printf("Timer ISR\n");
	
	//check_message();

        for (i =0;i < TMAX; i++)
        {
                if (tm[i].valid == 1 && tm[i].status == 1)
                {
                        --tm[i].elapsed;
                        if (tm[i].elapsed == 0)
                        {
                                printf ("Timer %d elapsed\n", tm[i].timerid);
                                if (tm[i].type == ONESHOT)
                                {
                                        tm[i].status = 0;
					message.mesg_type = 1;
					message.mesg_text[0] = 3;
					message.mesg_text[1] = TIMER;
                                        message.mesg_text[2] = tm[i].msgid;
					//printf ("*******Sending Expiry Message*************");
                                        send_msg(tm[i].taskid, &message, sizeof(message));
					//delete_timer();
                                }
                                else
                                {
                                        tm[i].elapsed = tm[i].reload;
					message.mesg_type = 1;
					message.mesg_text[0] = 3;
					message.mesg_text[1] = TIMER;
                                        message.mesg_text[2] = tm[i].msgid;
					//printf ("*******Sending Expiry Message*************");
                                        send_msg(tm[i].taskid, &message, sizeof(message));
					//delete_timer();
                                        //tm[i].ptr();
                                }
                        }
                }
       }

}

int initialize_timer()
{
	struct sigevent sev;
    	struct itimerspec its;
    	long long freq_nanosecs;
    	sigset_t mask;
    	struct sigaction sa;

    	printf("Establishing handler for signal %d\n", SIG);
   	sa.sa_flags = SA_SIGINFO;
    	sa.sa_sigaction = timer_isr;
   	sigemptyset(&sa.sa_mask);
    	sigaction(SIG, &sa, NULL);

    	sev.sigev_notify = SIGEV_SIGNAL;
    	sev.sigev_signo = SIGUSR1;
    	sev.sigev_value.sival_ptr = &timerid;
    	timer_create(CLOCKID, &sev, &timerid);
    	/* Start the timer */

    	its.it_value.tv_sec = 1;
    	its.it_value.tv_nsec = 0;
    	its.it_interval.tv_sec = its.it_value.tv_sec;
    	its.it_interval.tv_nsec = its.it_value.tv_nsec;

    	timer_settime(timerid, 0, &its, NULL);
}


int create_timer(int *timer_id, TASKLISTS tskid, MESSAGE msgid, char type, char interval)
{
        int i;

        for (i=0; i < TMAX; i++)
        {
                if (tm[i].valid == 0)
                {
                        *timer_id     = i + 1;
                        tm[i].valid   = 1;
                        tm[i].type    = type;
                        tm[i].elapsed = interval;
                        tm[i].reload  = interval;
                        tm[i].status  = 0;
			tm[i].taskid = tskid;
			tm[i].msgid = msgid;
                        tm[i].timerid = i + 1;
                        break;
                }
        }

        if (i == TMAX)
        {
                *timer_id = -1;
                return -1;
        }
        else
        {
                printf("Timer has been created, timer id = %d.\n",i+1);
                return i+1;
        }
}

int start_timer(int timer_id)
{
        int i = timer_id - 1;
        if (timer_id <0 || timer_id > TMAX)
        {
                printf ("Invalid Timer ID\n");
                return -1;
        }

        if (tm[i].valid == 1)
        {
                tm[i].status  = 1;
                //tm[i].ptr = ptr;
                printf ("Timer %d started\n", timer_id);
                return 0;
        }
        else
        {
                printf ("Timer ID not created\n");
                return -1;
        }
}

int stop_timer(int timer_id)
{
        int i = timer_id - 1;
        if (timer_id <0 || timer_id > TMAX)
        {
                printf ("Invalid Timer ID\n");
                return -1;
        }

        if (tm[i].valid == 1)
        {
		tm[i].valid = 0;
                tm[i].status  = 0;
                //tm[i].ptr = ptr;
                printf ("Timer %d started\n", timer_id);
                return 0;
        }
        else
        {
                printf ("Timer ID not created\n");
                return -1;
        }
}

void delete_timer()
{
	//static int i = 0;
	//i++;

	//if (i == 10)
	//{
		timer_delete(timerid);
	//	i = 0;
	//}
}

int main(int argc, char *argv[])
{
	printf ("Iam timer\n");
	int timer_id;
        MSGQDATA message;
        char buff[20];

        if (create_shm() == -1)
        {
                printf ("Shm creation error\n");
                exit(1);
        }
	printf ("Status of Timer = %d\n", pshminfo->timerstatus);

        if (create_msgq() == -1)
        {
                printf ("Msgq creation error\n");
                exit(1);
        }


	initialize_timer();

	create_timer(&timer_id,0, MSG_HEALTH_CHK_TIMER, PERIODIC, 25);
        start_timer(timer_id);
#if 0
        create_timer(&timer_id,1, MSG_CHK1_7_TASK, ONESHOT, 5);
        start_timer(timer_id);

        create_timer(&timer_id,2, MSG_CHK2_6_TASK, ONESHOT, 10);
        start_timer(timer_id);
#endif
        create_timer(&timer_id,DELIVERY, MSG_DRUG_DELIVERY_TIMER, PERIODIC, 1);
        start_timer(timer_id);
	create_timer(&timer_id,ALARM, MSG_ALARM_H, PERIODIC, 5);
        start_timer(timer_id);

        while(pshminfo->timerstatus == 1)
        {
#if 0
		if (recv_msg_nowait(8, &message, sizeof(message)) != -1)
                {
                        printf("timer received message \n");
                        if (message.mesg_text[0] < 3)
                        {
                                printf ("Timer Received Invalid Message \n");
                        }
                        else
                        {
                                switch (message.mesg_text[2])
                                {
                                        case MSG_PING:
                                                message.mesg_type = 1;
                                                message.mesg_text[0] = 3;
                                                message.mesg_text[1] = 8;
                                                message.mesg_text[2] = MSG_PING_ACK;
                                                send_msg(0, &message, sizeof(message));
                                        break;
                                        case MSG_HEALTHCHK:
                                                message.mesg_type = 1;
                                                message.mesg_text[0] = 3;
                                                message.mesg_text[1] = 8;
                                                message.mesg_text[2] = MSG_HEALTHCHK_ACK;
                                                send_msg(0, &message, sizeof(message));
					break;
                                        case MSG_SHUTDOWN:
                                                message.mesg_type = 1;
                                                message.mesg_text[0] = 3;
                                                message.mesg_text[1] = 7;
                                                message.mesg_text[2] = MSG_SHUTDOWN_ACK;
                                                send_msg(0, &message, sizeof(message));
                                                shutdwn = 1;
                                        break;
                                }
                        }
		}
#endif
        }
	delete_timer();
	printf ("Timer exited\n");

}



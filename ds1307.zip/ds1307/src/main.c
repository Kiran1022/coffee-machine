/**
 *    Keil project for DS1307 RTC library
 *
 *    Before you start, select your target, on the right of the "Load" button
 *
 *    @author     Tilen Majerle
 *    @email        tilen@majerle.eu
 *    @website    http://stm32f4-discovery.net
 *    @ide        Keil uVision 5
 */
/* Include core modules */
#include <defines.h>
#include "stm32f4xx.h"
/* Include my libraries here */
#include "tm_stm32f4_ds1307.h"
#include "tm_stm32f4_adc.h"
//#include "tm_stm32f4_ili9341.h"
#include "tm_stm32f4_disco.h"
#include <stdio.h>

#include "stm32f4xx.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_tim.h"

const uint16_t LEDS = GPIO_Pin_13 | GPIO_Pin_12;;
const uint16_t USER_BUTTON = GPIO_Pin_0;

int brightLed1 = 0;
int brigthLed2 = 5;
int delta = 1;
int lastButtonStatus = RESET;


void delay();


void initLeds();
void initTimer();
void initPWM();


void rot7deg();
void delay(uint32_t ms);

struct stepper
{
	float curr_angle;
	uint32_t * port;
}s1;

struct fan
{
	int speed;

}f1;

struct light
{
	int status;
	uint32_t * addr;

}l1;

struct ldr
{
	uint16_t intensity;
	uint32_t * addr;

}ld1;

struct temp
{
	uint16_t temp;
	uint32_t * addr;
}t1;

struct motion
{
	uint32_t moving;
	uint32_t * addr;
}m1;


int main(void) {
    char str[100];
    TM_DS1307_Time_t time;
    uint8_t last;

    /* Initialize system */

    SystemInit();



    /* Initialize DS1307 */
    if (TM_DS1307_Init() != TM_DS1307_Result_Ok) {

        while (1);
    }

    //initButton();

      initTimer();
      initPWM();



    		*(uint32_t *)(0x40023800 + 0x30) = 0x00000008; //clock
    		s1.port = (uint32_t *)(0x40020C00 + 0x00);
    	    *s1.port = 0x55000000; //gpio output mode for pd15,pd14
    	    *(uint32_t *)(s1.port + 0x18) = 0x00008000;// sets the enable for the stepper motor

    	    initLeds();
    /* Set date and time */
    /* Day 7, 26th May 2014, 02:05:00 */
    time.hours = 7;
    time.minutes = 59;
    time.seconds = 50;
    time.date = 26;
    time.day = 1;
    time.month = 5;
    time.year = 14;
    TM_DS1307_SetDateTime(&time);

    /* Set output pin to 4096 Hz */
    TM_DS1307_EnableOutputPin(TM_DS1307_OutputFrequency_4096Hz);
    TM_ADC_Init(ADC1, ADC_Channel_0);// initializes adc1 on PA0
    TM_ADC_Init(ADC2, ADC_Channel_1);//init PA1

    m1.addr = (uint32_t *)(0x40020C00 + 0x10);//motion sensor input on pd11


    TM_DS1307_Time_t save_time;
    while (1) {
        /* Get date and time */
        TM_DS1307_GetDateTime(&time);
        t1.temp = (TM_ADC_Read(ADC1, ADC_Channel_0) * 150 * 2) / 4095;
        ld1.intensity = TM_ADC_Read(ADC2,ADC_Channel_1);
        if(time.hours>=6&&time.hours<=18)
        {
        	if(time.minutes==0&&time.seconds==0)
        		rot7deg();
        }
        else if(time.hours==5&&time.minutes==0&&time.seconds==0)
        {
        	int count = 12;
        	while(count--)
        	{
        		rot7deg();
        	}
        }//stepper

        m1.moving = GPIO_ReadInputDataBit(GPIOD,GPIO_PIN_11);

        if(m1.moving == 0 )
        {
        	save_time = time;
        	 TIM_SetCompare1(TIM4, t1.temp*10);//fan speed
        	 GPIO_SetBits(GPIOD,GPIO_PIN_13);
        }
        else if( save_time.hours!=time.hours&&save_time.seconds==time.seconds && (save_time.minutes==time.minutes+40||time.minutes==save_time.minutes+20))
        {

        	//if(ld1.intensity>= 2048);

        	 TIM_SetCompare1(TIM4, 0);//fan speed
        	 GPIO_ResetBits(GPIOD,GPIO_PIN_13);



        }//light







        /* Display on console */
        printf(str, "Day: %d\nDate: %02d\nMonth: %02d\nYear: %04d\nHours: %02d\nMinutes: %02d\nSeconds: %02d", time.day, time.date, time.month, time.year + 2000, time.hours, time.minutes, time.seconds);


    }
}

void rot7deg()
{	int count = 4;
	while(count--)
	{
			*(uint32_t *)(0x40020C00 + 0x18) = *(uint32_t *)(0x40020C00 + 0x18) | 0x0000C000;//gives pulse for 1 step every 500 ms
			delay(50);
			*(uint32_t *)(0x40020C00 + 0x18) = *(uint32_t *)(0x40020C00 + 0x18) | 0x40008000;
			delay(50);

	}
}

void delay(uint32_t ms) {
        ms *= 3360;
        while(ms--) {
            __NOP();
        }
    }






void initLeds() {
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);

    GPIO_InitStructure.GPIO_Pin = LEDS;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

    GPIO_PinAFConfig(GPIOD, GPIO_PinSource13, GPIO_AF_TIM4);
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource12, GPIO_AF_TIM4);
}

void initTimer() {
    /* TIM4 clock enable */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);

    /* Compute the prescaler value */
    u32 PrescalerValue = (uint16_t) ((SystemCoreClock / 2) / 21000000) - 1;

    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    /* Time base configuration */
    TIM_TimeBaseStructure.TIM_Period = 1000;
    TIM_TimeBaseStructure.TIM_Prescaler = PrescalerValue;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;

    TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);
}

void initPWM() {
    TIM_OCInitTypeDef TIM_OCInitStructure;

    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = 0;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;

    /* PWM1 Mode configuration: Channel2 (GPIOD Pin 13)*/
    TIM_OC2Init(TIM4, &TIM_OCInitStructure);
    TIM_OC2PreloadConfig(TIM4, TIM_OCPreload_Enable);

    /* PWM1 Mode configuration: Channel1 (GPIOD Pin 12)*/
    TIM_OC1Init(TIM4, &TIM_OCInitStructure);
    TIM_OC1PreloadConfig(TIM4, TIM_OCPreload_Enable);

    TIM_Cmd(TIM4, ENABLE);
}

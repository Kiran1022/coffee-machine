#include "main.h"

int main() {
    init();

    do {
        //loop();
        control_motor();
    } while (1);
}

void init() {
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
    GPIO_InitTypeDef gpio;
    GPIO_InitTypeDef gpio1;
    GPIO_StructInit(&gpio);
    GPIO_StructInit(&gpio1);
    gpio.GPIO_Mode = GPIO_Mode_OUT;
    gpio.GPIO_Pin = LEDS;
    gpio1.GPIO_Mode = GPIO_Mode_OUT;
    gpio1.GPIO_Pin = MOTORS;
    GPIO_Init(GPIOD, &gpio);
    GPIO_Init(GPIOB, &gpio1);

    GPIO_SetBits(GPIOD, LEDS);
    GPIO_ResetBits(GPIOB, MOTORS);
}

void loop() {
    static uint32_t counter = 0;

    ++counter;

    GPIO_ResetBits(GPIOD, LEDS);
    GPIO_SetBits(GPIOD, LED[counter % 4]);

    delay(250);
}

void control_motor() {
    static uint32_t counterm = 0;
    static uint8_t direction = 0;

    ++counterm;

    if (counterm <= 3)
    {
    	if (direction == 0)
    	{
    		direction = 1;
    		GPIO_SetBits(GPIOB, MOTOR[0]);
    		GPIO_SetBits(GPIOB, MOTOR[1]);
    	}
    }
    else if (counterm <= 10)
	{
		if (direction == 1)
		{
			direction = 2;
			GPIO_ResetBits(GPIOB, MOTOR[0]);
			GPIO_ResetBits(GPIOB, MOTOR[1]);
		}
	}
    else if (counterm <= 13)
	{
		if (direction == 2)
		{
			direction = 3;
			GPIO_SetBits(GPIOB, MOTOR[0]);
			GPIO_SetBits(GPIOB, MOTOR[2]);
		}
	}
    else if (counterm <= 20)
	{
		if (direction == 3)
		{
			direction = 0;
			GPIO_ResetBits(GPIOB, MOTOR[0]);
			GPIO_ResetBits(GPIOB, MOTOR[2]);
		}
	}
    else
    {
    	counterm = 0;
    }

    delay(1000);
}

void delay(uint32_t ms) {
    ms *= 3360;
    while(ms--) {
        __NOP();
    }
}
